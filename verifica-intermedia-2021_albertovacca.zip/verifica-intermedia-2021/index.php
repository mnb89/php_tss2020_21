<?php

// require './entity/User.php';
require './lib/UsersSearchFunctions.php';


$listaUtenti=[];
$fileString = file_get_contents('./dataset/users-management-system.json');
$res = json_decode($fileString, true);
$searchId="";

$listaUtenti=JSONObj($res);

function sanitizeName($name){
    $lowName= strtolower($name);
    $upFirstL= ucwords($lowName);
    
    return $upFirstL;
}

if(isset($_GET['searchFirstName']) && trim($_GET['searchFirstName'])!==''){
    $searchFirstName=trim(filter_var($_GET['searchFirstName'],FILTER_SANITIZE_STRING));
    $listaUtenti=array_filter($listaUtenti, searchFirstName($searchFirstName));

    if(isset($_GET['searchLastName']) && trim($_GET['searchLastName'])!==''){

        $searchLastName=trim(filter_var($_GET['searchLastName'],FILTER_SANITIZE_STRING));
        $listaUtenti=array_filter($listaUtenti, searchLastName($searchLastName));

        if(isset($_GET['searchEta']) && trim($_GET['searchEta'])!==''){
            $searchEta=trim(filter_var($_GET['searchEta']));
            $listaUtenti=array_filter($listaUtenti, searchEta($searchEta));

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
                
            }else{
                $searchEmail="";
            }

        }else{
            $searchEta="";

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }
        }

    }else{
        $searchLastName="";

        if(isset($_GET['searchEta']) && trim($_GET['searchEta'])!==''){
            $searchEta=trim(filter_var($_GET['searchEta']));
            $listaUtenti=array_filter($listaUtenti, searchEta($searchEta));

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }

        }else{
            $searchEta="";

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }
        }

    }

}else{

    $searchFirstName="";

    if(isset($_GET['searchLastName']) && trim($_GET['searchLastName'])!==''){

        $searchLastName=trim($_GET['searchLastName']);
        $listaUtenti=array_filter($listaUtenti, searchLastName($searchLastName));

        if(isset($_GET['searchEta']) && trim($_GET['searchEta'])!==''){
            $searchEta=trim(filter_var($_GET['searchEta']));
            $listaUtenti=array_filter($listaUtenti, searchEta($searchEta));

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }


        }else{
            $searchEta="";

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }
        }

    }else{
        $searchLastName="";

        if(isset($_GET['searchEta']) && trim($_GET['searchEta'])!==''){
            $searchEta=trim(filter_var($_GET['searchEta']));
            $listaUtenti=array_filter($listaUtenti, searchEta($searchEta));

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }

        }else{
            $searchEta="";

            if(isset($_GET['searchEmail']) && trim($_GET['searchEmail'])!==''){
                $searchEmail=trim(filter_var($_GET['searchEmail']));
                $listaUtenti=array_filter($listaUtenti, searchEmail($searchEmail));
            }else{
                $searchEmail="";
            }
        }
    }
}




?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <style>
        input.form-control {
            padding: 2px;
            line-height: 100%;
            font-size: 1.5rem;
        }
    </style>
</head>

<body>
    <header class="container-fluid bg-secondary text-light p-2">
        <div class="container">
            <h1 class="display-3 mb-0">
                User management system
            </h1>
            <h2 class="display-6">user list</h2>
        </div>
    </header>
    <form action="#" method="get">
        <div class="container">
            <table class="table">
                <tr>
                    <th>id</th>
                    <th>nome</th>
                    <th>cognome</th>
                    <th>email</th>
                    <th cellspan="2">età</th>
                </tr>
                <tr>
                    <th>
                        <input class="form-control" name="searchId" type="text" value="<?=$searchId?>">
                    </th>
    
                    <th>
                        <input class="form-control" name="searchFirstName" type="text" value="<?=$searchFirstName?>">
                    </th>
    
                    <th>
                        <input class="form-control" name="searchLastName" type="text" value="<?=$searchLastName?>">
                    </th>
    
                    <th>
                        <input class="form-control" name="searchEmail" type="text" value="<?=$searchEmail?>">
                    </th>
    
                    <th>
                        <input class="form-control" name="searchEta" type="text" value="<?=$searchEta?>">
                    </th>
                    <th>
                        <button class="btn btn-primary" type="submit">cerca</button>
                    </th>
                </tr>
                <?php foreach ($listaUtenti as $utente) {?>
                    <tr>
                    <td><?=$utente->getuserId()?></td>
                    <td><?=$utente->getFirstName()?></td>
                    <td><?=$utente->getLastName()?></td>
                    <td><?=$utente->getEmail()?></td>
                    <td><?=$utente->getAge()?></td>
                    </tr>
                <?php  }?> 
            </table>
        </div>        
    </form>
</body>

</html>