<?php

require './entity/User.php';

function JSONObj($json){

    foreach ($json as $utenti) {
        $userId=$utenti['id'];
        $firstName=$utenti['firstName'];
        $lastName=sanitizeName($utenti['lastName']);
        $email=$utenti['email'];
        $birthday=$utenti['birthday'];
        $user= new User($userId,$firstName,$lastName,$email,$birthday);
        $listaUtenti[]=$user;
    }

    return $listaUtenti;
}


function searchFirstName($searchFirstName){

return function ($userItem) use ($searchFirstName){ 

        $result = stripos($userItem->getFirstName(), $searchFirstName) !== false;
        return $result;
    };
}

function searchLastName($searchLastName){

    return function ($userItem) use ($searchLastName){ 
    
            $result = stripos($userItem->getLastName(), $searchLastName) !== false;
            return $result;
    };
}

function searchEta($searchEta){

    return function ($userItem) use ($searchEta){ 
        
            $result = stripos($userItem->getAge(), $searchEta) !== false;
            return $result;
    };
}

function searchEmail($searchEmail){

    return function ($userItem) use ($searchEmail){ 
        
            $result = stripos($userItem->getEmail(), $searchEmail) !== false;
            return $result;
    };
}

function searchId($searchId){

    return function ($userItem) use ($searchId){ 
        
            $result = stripos($userItem->getUserId(), $searchId) !== false;
            return $result;
    };
}
