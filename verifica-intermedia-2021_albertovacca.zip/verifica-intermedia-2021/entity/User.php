<?php


class User {

    private $userId;
    private $firstName;
    private $lastName;
    private $birthday;
    private $email;


    function  __construct($id,$firstName,$lastName,$email,$birthday) {
        $this->userId=$id;
        $this->firstName=$firstName;
        $this->lastName=$lastName;
        $this->email=$email;
        $this->birthday=$birthday;
    }


    public function getUserId()
    {
    return $this->userId;
    }

    
    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }
    
    /**
     * Get the value of birthday
     */ 
    public function getBirthday()
    {
        return $this->birthday;
    }
    
    /**
     * Get the value of lastName
     */ 
    public function getLastName()
    {
        return $this->lastName;
    }
    
    /**
     * Get the value of firstName
     */ 
    public function getFirstName()
    {
        return $this->firstName;
    }


    public function getAge() {
        $today=new DateTime();
        $birth= new DateTime($this->birthday);
        
        return floor(($today->format('Ym')-$birth->format('Ym'))/100);
    }
    
    
    public function isAdult(){
    
        return $this->getAge()>18 ? true:false;
    }
    
    
    public function stampAll(){
        echo "-----------------------\n";
        echo $this->getUserId();
        echo "\n";
        echo $this->firstName;
        echo "\n";
        echo $this->lastName;
        echo "\n";
        echo $this->email;
        echo "\n";
        echo $this->birthday;
        echo "\n";
        echo "-----------------------";
    
    }
}