<?php
require './lib/UsersSearchFunctions.php';


function sanitizeName($name){
    $lowName= strtolower($name);
    $upFirstL= ucwords($lowName);

    return $upFirstL;
}

// $user1= new User(1,"Adamo","ROSSI","adamo.rossi@email.com","2002-06-12");


// echo floor($user1->getAge()/100);

// JSONObj('./dataset/users-management-system.json');    

// $fileString = file_get_contents($filepath);
    $fileString = file_get_contents('./dataset/users-management-system.json');
    $res = json_decode($fileString, true);
    
    $listaUtenti=[];
    foreach ($res as $utenti) {
        $userId=$utenti['id'];
        $firstName=$utenti['firstName'];
        $lastName=sanitizeName($utenti['lastName']);
        $email=$utenti['email'];
        $birthday=$utenti['birthday'];
        $user= new User($userId,$firstName,$lastName,$email,$birthday);
        // $user->stampAll();
        $listaUtenti[]=$user;
    }


    print_r($listaUtenti);